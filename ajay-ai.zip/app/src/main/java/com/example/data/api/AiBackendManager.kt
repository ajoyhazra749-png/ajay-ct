package com.example.data.api

import android.content.Context
import android.content.SharedPreferences
import com.example.BuildConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

data class ApiConfig(
    val geminiApiKey: String = "",
    val customApiEndpoint: String = "",
    val selectedModel: String = "gemini-2.5-flash",
    val isSimulationModeAllowed: Boolean = true
)

sealed class ApiGenerationResult {
    data class Success(val content: String, val model: String, val tokensUsed: Int = 120) : ApiGenerationResult()
    data class BackendRequired(val message: String) : ApiGenerationResult()
    data class Error(val error: String) : ApiGenerationResult()
}

class AiBackendManager(private val context: Context) {
    private val prefs: SharedPreferences =
        context.getSharedPreferences("ajay_ai_api_prefs", Context.MODE_PRIVATE)

    private val httpClient = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .build()

    fun getApiConfig(): ApiConfig {
        val savedKey = prefs.getString("gemini_api_key", "") ?: ""
        // Check BuildConfig fallback if available
        val effectiveKey = if (savedKey.isNotBlank()) {
            savedKey
        } else {
            try {
                val field = BuildConfig::class.java.getField("GEMINI_API_KEY")
                val key = field.get(null) as? String ?: ""
                if (key.isNotBlank() && !key.contains("MY_GEMINI_API_KEY")) key else ""
            } catch (e: Exception) {
                ""
            }
        }

        return ApiConfig(
            geminiApiKey = effectiveKey,
            customApiEndpoint = prefs.getString("custom_api_endpoint", "https://api.ajayai.internal/v1") ?: "",
            selectedModel = prefs.getString("selected_model", "gemini-2.5-flash") ?: "gemini-2.5-flash",
            isSimulationModeAllowed = prefs.getBoolean("allow_simulation", true)
        )
    }

    fun saveApiConfig(config: ApiConfig) {
        prefs.edit()
            .putString("gemini_api_key", config.geminiApiKey)
            .putString("custom_api_endpoint", config.customApiEndpoint)
            .putString("selected_model", config.selectedModel)
            .putBoolean("allow_simulation", config.isSimulationModeAllowed)
            .apply()
    }

    fun hasValidBackend(): Boolean {
        val config = getApiConfig()
        return config.geminiApiKey.isNotBlank() || config.customApiEndpoint.isNotBlank()
    }

    suspend fun generateStoryOrScript(prompt: String): ApiGenerationResult = withContext(Dispatchers.IO) {
        val config = getApiConfig()
        if (config.geminiApiKey.isBlank()) {
            return@withContext ApiGenerationResult.BackendRequired(
                "No AI Backend configured. Please connect a Gemini API key or custom webhook endpoint in API Settings to execute real cloud inference."
            )
        }

        try {
            val url = "https://generativelanguage.googleapis.com/v1beta/models/${config.selectedModel}:generateContent?key=${config.geminiApiKey}"
            val jsonPayload = JSONObject().apply {
                put("contents", JSONArray().apply {
                    put(JSONObject().apply {
                        put("parts", JSONArray().apply {
                            put(JSONObject().apply {
                                put("text", "You are the creative engine of AJAY AI platform. Generate a high quality, compelling output for this prompt: $prompt")
                            })
                        })
                    })
                })
            }

            val requestBody = jsonPayload.toString().toRequestBody("application/json; charset=utf-8".toMediaType())
            val request = Request.Builder()
                .url(url)
                .post(requestBody)
                .build()

            val response = httpClient.newCall(request).execute()
            val responseBody = response.body?.string() ?: ""

            if (!response.isSuccessful) {
                return@withContext ApiGenerationResult.Error("API returned code ${response.code}: $responseBody")
            }

            val jsonResponse = JSONObject(responseBody)
            val candidates = jsonResponse.optJSONArray("candidates")
            if (candidates != null && candidates.length() > 0) {
                val firstCandidate = candidates.getJSONObject(0)
                val content = firstCandidate.getJSONObject("content")
                val parts = content.getJSONArray("parts")
                val text = parts.getJSONObject(0).getString("text")
                return@withContext ApiGenerationResult.Success(
                    content = text,
                    model = config.selectedModel
                )
            } else {
                return@withContext ApiGenerationResult.Error("Empty candidate response from AI backend.")
            }
        } catch (e: Exception) {
            return@withContext ApiGenerationResult.Error("Network error connecting to AI backend: ${e.localizedMessage}")
        }
    }
}
