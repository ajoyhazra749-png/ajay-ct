package com.example.data.model

import com.example.R

data class CreationItem(
    val id: Long = System.currentTimeMillis(),
    val title: String,
    val prompt: String,
    val category: CreationCategory,
    val aspectRatio: String = "9:16",
    val createdAt: Long = System.currentTimeMillis(),
    val drawableRes: Int? = null,
    val mediaUri: String? = null,
    val modelName: String = "AJAY Diffusion Ultra v3.5",
    val status: String = "Completed",
    val creditsCost: Int = 5,
    val isFavorite: Boolean = false,
    val outputContent: String? = null,
    val audioDuration: String? = null
) {
    companion object {
        fun getPreloadedCreations(): List<CreationItem> = listOf(
            CreationItem(
                id = 101L,
                title = "Cute 3D Cartoon Tomato",
                prompt = "A cute 3D cartoon tomato character driving an old car on a village road, cinematic lighting, vertical 9:16.",
                category = CreationCategory.AI_IMAGE,
                aspectRatio = "9:16",
                drawableRes = R.drawable.hero_ai_tomato_1790666843637,
                modelName = "AJAY Render 3D Pro",
                creditsCost = 5,
                isFavorite = true,
                outputContent = "Masterpiece 3D render generated with Ray-traced cinematic lighting at 2160x3840 resolution."
            ),
            CreationItem(
                id = 102L,
                title = "Cyber City Neon Highway",
                prompt = "Cinematic futuristic cybernetic neon cityscape with motion blur light trails and camera framing overlay, 8k render",
                category = CreationCategory.AI_VIDEO,
                aspectRatio = "16:9",
                drawableRes = R.drawable.card_ai_video_1790666856784,
                modelName = "AJAY CineMotion v2.4",
                creditsCost = 15,
                isFavorite = true,
                outputContent = "4K 60fps cinematic video clip (4.8 seconds loop) rendered with temporal motion consistency."
            ),
            CreationItem(
                id = 103L,
                title = "Neon Cosmic Synthwave",
                prompt = "Dreamy lofi synthwave beat with warm vintage keys and rain atmosphere, 85 bpm, cosmic synth frequencies",
                category = CreationCategory.AI_MUSIC,
                aspectRatio = "16:9",
                drawableRes = R.drawable.card_ai_music_1790666873534,
                modelName = "AJAY AudioPulse Studio",
                creditsCost = 10,
                isFavorite = false,
                audioDuration = "02:45",
                outputContent = "Full stereo track generated: 320kbps MP3 with stems for drums, bass, synth, and atmospheric pads."
            ),
            CreationItem(
                id = 104L,
                title = "The Chrono Relic: Ep 1",
                prompt = "A gripping sci-fi screenplay scene where an archivist in Neo-Kyoto deciphers an audio transmission from 2088.",
                category = CreationCategory.AI_STORY,
                aspectRatio = "1:1",
                modelName = "AJAY Narrative Omni (Gemini Powered)",
                creditsCost = 5,
                isFavorite = true,
                outputContent = """
                    EXT. NEO-KYOTO SKYWAYS - NIGHT
                    Heavy acid rain pings against the reinforced plexiglass of ARCHIVE TOWER 7.
                    
                    KAIEN (30s, optic scanner flickering cyan) wipes grease from an ancient brass cylinder.
                    
                    KAIEN
                    (whispering)
                    "You weren't made in our century. Who sent you back?"
                    
                    The artifact clicks. A holographic frequency oscillates in mid-air.
                    A distorted voice emerges—Kaien's own voice, twenty years older.
                    
                    VOICE (FROM CYLINDER)
                    "Kaien. Do not decrypt the Seventh Key. If you hear this, they've already breached Sector 4."
                """.trimIndent()
            ),
            CreationItem(
                id = 105L,
                title = "Narrator Clone: Nova Deep",
                prompt = "Deep cinematic narrator voice with calm British tone, studio quality acoustics, narration for documentary.",
                category = CreationCategory.AI_VOICE,
                aspectRatio = "1:1",
                modelName = "AJAY Neural Voice HD",
                creditsCost = 8,
                isFavorite = false,
                audioDuration = "00:48",
                outputContent = "Voice synthesis model calibrated at 48kHz studio master. Warm low-end presence with gentle natural breathing cadence."
            )
        )
    }
}
