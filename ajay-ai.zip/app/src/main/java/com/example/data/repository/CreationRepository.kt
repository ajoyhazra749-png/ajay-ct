package com.example.data.repository

import android.content.Context
import android.content.SharedPreferences
import com.example.data.local.AppDatabase
import com.example.data.local.CreationEntity
import com.example.data.model.CreationCategory
import com.example.data.model.CreationItem
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

class CreationRepository(private val context: Context) {
    private val db = AppDatabase.getInstance(context)
    private val dao = db.creationDao()
    private val prefs: SharedPreferences =
        context.getSharedPreferences("ajay_ai_user_prefs", Context.MODE_PRIVATE)

    fun getCreditsBalance(): Int {
        return prefs.getInt("user_credits", 100)
    }

    fun deductCredits(amount: Int): Boolean {
        val current = getCreditsBalance()
        if (current >= amount) {
            prefs.edit().putInt("user_credits", current - amount).apply()
            return true
        }
        return false
    }

    fun addCredits(amount: Int) {
        val current = getCreditsBalance()
        prefs.edit().putInt("user_credits", current + amount).apply()
    }

    fun resetCreditsToDefault() {
        prefs.edit().putInt("user_credits", 100).apply()
    }

    fun getAllCreations(): Flow<List<CreationItem>> {
        return dao.getAllCreations().map { list ->
            list.map { it.toDomain() }
        }
    }

    suspend fun initializePreloadedIfEmpty() {
        if (dao.getCount() == 0) {
            val starterItems = CreationItem.getPreloadedCreations()
            dao.insertAll(starterItems.map { CreationEntity.fromDomain(it) })
        }
    }

    suspend fun saveCreation(item: CreationItem): Long {
        return dao.insertCreation(CreationEntity.fromDomain(item))
    }

    suspend fun deleteCreation(id: Long) {
        dao.deleteById(id)
    }

    suspend fun toggleFavorite(id: Long, currentFav: Boolean) {
        dao.updateFavorite(id, !currentFav)
    }
}
