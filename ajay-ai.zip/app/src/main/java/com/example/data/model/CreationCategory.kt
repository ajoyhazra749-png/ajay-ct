package com.example.data.model

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.MenuBook
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Collections
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.HighQuality
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.MovieCreation
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.RecordVoiceOver
import androidx.compose.material.icons.filled.SlowMotionVideo
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector

enum class CreationCategory(
    val id: String,
    val title: String,
    val subtitle: String,
    val defaultCost: Int,
    val icon: ImageVector,
    val gradientColors: List<Color>,
    val placeholderPrompt: String,
    val isCoreCard: Boolean = false
) {
    AI_IMAGE(
        id = "ai_image",
        title = "AI Image",
        subtitle = "Text to 8K Art & Photorealism",
        defaultCost = 5,
        icon = Icons.Default.Image,
        gradientColors = listOf(Color(0xFF8B5CF6), Color(0xFF6366F1)),
        placeholderPrompt = "A futuristic cyberpunk samurai standing on a neon rainlit street, volumetric fog, 8k...",
        isCoreCard = true
    ),
    AI_VIDEO(
        id = "ai_video",
        title = "AI Video",
        subtitle = "Cinematic Motion & Clips",
        defaultCost = 15,
        icon = Icons.Default.MovieCreation,
        gradientColors = listOf(Color(0xFF06B6D4), Color(0xFF3B82F6)),
        placeholderPrompt = "Slow motion drone shot sweeping over glowing alien crystals in deep space nebula...",
        isCoreCard = true
    ),
    AI_VOICE(
        id = "ai_voice",
        title = "AI Voice",
        subtitle = "Voice Clone & Synthetic Audio",
        defaultCost = 8,
        icon = Icons.Default.GraphicEq,
        gradientColors = listOf(Color(0xFFEC4899), Color(0xFFA855F7)),
        placeholderPrompt = "Deep cinematic narrator voice with calm British tone, studio quality acoustics...",
        isCoreCard = true
    ),
    TEXT_TO_SPEECH(
        id = "text_to_speech",
        title = "Text to Speech",
        subtitle = "Natural Multi-Voice Reader",
        defaultCost = 4,
        icon = Icons.Default.RecordVoiceOver,
        gradientColors = listOf(Color(0xFF10B981), Color(0xFF059669)),
        placeholderPrompt = "Welcome to AJAY AI creator platform. Your imagination is the only limit to what we can produce today.",
        isCoreCard = false
    ),
    SPEECH_TO_TEXT(
        id = "speech_to_text",
        title = "Speech to Text",
        subtitle = "Accurate Audio Transcription",
        defaultCost = 4,
        icon = Icons.Default.Mic,
        gradientColors = listOf(Color(0xFFF59E0B), Color(0xFFD97706)),
        placeholderPrompt = "Tap record or upload audio to transcribe interviews, podcasts, or notes instantly...",
        isCoreCard = false
    ),
    IMAGE_TO_VIDEO(
        id = "image_to_video",
        title = "Image to Video",
        subtitle = "Animate Still Photos into Motion",
        defaultCost = 12,
        icon = Icons.Default.SlowMotionVideo,
        gradientColors = listOf(Color(0xFF3B82F6), Color(0xFF8B5CF6)),
        placeholderPrompt = "Camera zooming into the horizon, gentle wind blowing through trees, water rippling...",
        isCoreCard = false
    ),
    AI_STORY(
        id = "ai_story",
        title = "AI Story & Script",
        subtitle = "Plotlines, Screenplays & Dialogue",
        defaultCost = 5,
        icon = Icons.AutoMirrored.Filled.MenuBook,
        gradientColors = listOf(Color(0xFFF43F5E), Color(0xFFFB7185)),
        placeholderPrompt = "Write a captivating sci-fi thriller opening where a time traveler discovers their own warning...",
        isCoreCard = true
    ),
    AI_MUSIC(
        id = "ai_music",
        title = "AI Music",
        subtitle = "Full Instrumental & Lofi Beats",
        defaultCost = 10,
        icon = Icons.Default.MusicNote,
        gradientColors = listOf(Color(0xFF8B5CF6), Color(0xFFEC4899)),
        placeholderPrompt = "Dreamy lofi synthwave beat with warm vintage keys and rain atmosphere, 85 bpm...",
        isCoreCard = true
    ),
    AI_ENHANCE(
        id = "ai_enhance",
        title = "AI Enhance / Upscale",
        subtitle = "4K Super Resolution & Face Restore",
        defaultCost = 6,
        icon = Icons.Default.HighQuality,
        gradientColors = listOf(Color(0xFF14B8A6), Color(0xFF06B6D4)),
        placeholderPrompt = "Select an existing image to 4x upscale with crisp edge fidelity and dynamic range boost...",
        isCoreCard = false
    ),
    MY_CREATIONS(
        id = "my_creations",
        title = "My Creations",
        subtitle = "Your Saved Portfolio & Downloads",
        defaultCost = 0,
        icon = Icons.Default.Collections,
        gradientColors = listOf(Color(0xFF6366F1), Color(0xFFA855F7)),
        placeholderPrompt = "Browse and manage all previously generated artwork, videos, voice clips, and scripts.",
        isCoreCard = false
    );

    val brush: Brush
        get() = Brush.linearGradient(gradientColors)
}
