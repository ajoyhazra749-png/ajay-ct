package com.example.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey
import com.example.data.model.CreationCategory
import com.example.data.model.CreationItem

@Entity(tableName = "creations")
data class CreationEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val title: String,
    val prompt: String,
    val categoryId: String,
    val aspectRatio: String,
    val createdAt: Long,
    val drawableRes: Int?,
    val mediaUri: String?,
    val modelName: String,
    val status: String,
    val creditsCost: Int,
    val isFavorite: Boolean,
    val outputContent: String?,
    val audioDuration: String?
) {
    fun toDomain(): CreationItem {
        val cat = CreationCategory.entries.find { it.id == categoryId } ?: CreationCategory.AI_IMAGE
        return CreationItem(
            id = id,
            title = title,
            prompt = prompt,
            category = cat,
            aspectRatio = aspectRatio,
            createdAt = createdAt,
            drawableRes = drawableRes,
            mediaUri = mediaUri,
            modelName = modelName,
            status = status,
            creditsCost = creditsCost,
            isFavorite = isFavorite,
            outputContent = outputContent,
            audioDuration = audioDuration
        )
    }

    companion object {
        fun fromDomain(item: CreationItem): CreationEntity = CreationEntity(
            id = if (item.id > 1000L) 0L else item.id,
            title = item.title,
            prompt = item.prompt,
            categoryId = item.category.id,
            aspectRatio = item.aspectRatio,
            createdAt = item.createdAt,
            drawableRes = item.drawableRes,
            mediaUri = item.mediaUri,
            modelName = item.modelName,
            status = item.status,
            creditsCost = item.creditsCost,
            isFavorite = item.isFavorite,
            outputContent = item.outputContent,
            audioDuration = item.audioDuration
        )
    }
}
