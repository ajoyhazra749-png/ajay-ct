package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.example.data.model.CreationCategory
import com.example.ui.components.CreationCardsRow
import com.example.ui.components.ExamplePromptCard
import com.example.ui.components.FeatureGrid
import com.example.ui.components.GenerateButton
import com.example.ui.components.PromptBox
import com.example.ui.theme.DarkBackground

@Composable
fun HomeScreen(
    prompt: String,
    examplePrompt: String,
    selectedCategory: CreationCategory,
    creditsCost: Int,
    onPromptChange: (String) -> Unit,
    onUseExamplePrompt: () -> Unit,
    onCategorySelect: (CreationCategory) -> Unit,
    onGenerateClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(DarkBackground)
            .testTag("home_screen_content"),
        contentPadding = PaddingValues(bottom = 90.dp),
        verticalArrangement = Arrangement.spacedBy(18.dp)
    ) {
        // Large AI Prompt Box
        item {
            Box(modifier = Modifier.padding(horizontal = 16.dp)) {
                PromptBox(
                    prompt = prompt,
                    onPromptChange = onPromptChange,
                    onSurpriseMeClick = onUseExamplePrompt,
                    placeholderText = "What do you want to create?"
                )
            }
        }

        // Example Prompt Card
        item {
            Box(modifier = Modifier.padding(horizontal = 16.dp)) {
                ExamplePromptCard(
                    examplePrompt = examplePrompt,
                    onUsePrompt = onUseExamplePrompt
                )
            }
        }

        // Generate Button with Sparkle Icon
        item {
            Box(modifier = Modifier.padding(horizontal = 16.dp)) {
                GenerateButton(
                    creditsCost = creditsCost,
                    categoryTitle = selectedCategory.title,
                    onClick = onGenerateClick
                )
            }
        }

        // Separate Creation Cards for Image, Video, Voice, Story, and Music
        item {
            CreationCardsRow(
                selectedCategory = selectedCategory,
                onCategorySelect = onCategorySelect
            )
        }

        // 10 Main Features Grid
        item {
            FeatureGrid(
                selectedCategory = selectedCategory,
                onCategorySelected = onCategorySelect
            )
        }

        item {
            Spacer(modifier = Modifier.height(10.dp))
        }
    }
}
