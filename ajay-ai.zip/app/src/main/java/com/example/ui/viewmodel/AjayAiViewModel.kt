package com.example.ui.viewmodel

import android.app.Application
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.R
import com.example.data.api.AiBackendManager
import com.example.data.api.ApiConfig
import com.example.data.api.ApiGenerationResult
import com.example.data.model.CreationCategory
import com.example.data.model.CreationItem
import com.example.data.repository.CreationRepository
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

enum class NavigationTab(val title: String) {
    HOME("Home"),
    CREATE("Create"),
    CREATIONS("Creations"),
    PROFILE("Profile")
}

data class GenerationState(
    val isGenerating: Boolean = false,
    val currentStep: String = "",
    val progress: Float = 0f,
    val completedItem: CreationItem? = null,
    val error: String? = null
)

class AjayAiViewModel(application: Application) : AndroidViewModel(application) {
    private val repository = CreationRepository(application)
    private val apiBackendManager = AiBackendManager(application)
    private val vibrator = application.getSystemService(Vibrator::class.java)

    val examplePrompt = "A cute 3D cartoon tomato character driving an old car on a village road, cinematic lighting, vertical 9:16."

    private val _currentTab = MutableStateFlow(NavigationTab.HOME)
    val currentTab: StateFlow<NavigationTab> = _currentTab.asStateFlow()

    private val _prompt = MutableStateFlow("")
    val prompt: StateFlow<String> = _prompt.asStateFlow()

    private val _selectedCategory = MutableStateFlow(CreationCategory.AI_IMAGE)
    val selectedCategory: StateFlow<CreationCategory> = _selectedCategory.asStateFlow()

    private val _selectedAspectRatio = MutableStateFlow("9:16")
    val selectedAspectRatio: StateFlow<String> = _selectedAspectRatio.asStateFlow()

    private val _selectedStyle = MutableStateFlow("Cinematic 3D")
    val selectedStyle: StateFlow<String> = _selectedStyle.asStateFlow()

    private val _creditsBalance = MutableStateFlow(repository.getCreditsBalance())
    val creditsBalance: StateFlow<Int> = _creditsBalance.asStateFlow()

    private val _generationState = MutableStateFlow(GenerationState())
    val generationState: StateFlow<GenerationState> = _generationState.asStateFlow()

    private val _selectedCreation = MutableStateFlow<CreationItem?>(null)
    val selectedCreation: StateFlow<CreationItem?> = _selectedCreation.asStateFlow()

    private val _showApiConfigDialog = MutableStateFlow(false)
    val showApiConfigDialog: StateFlow<Boolean> = _showApiConfigDialog.asStateFlow()

    private val _showBackendNoticeDialog = MutableStateFlow(false)
    val showBackendNoticeDialog: StateFlow<Boolean> = _showBackendNoticeDialog.asStateFlow()

    private val _showCreditsDialog = MutableStateFlow(false)
    val showCreditsDialog: StateFlow<Boolean> = _showCreditsDialog.asStateFlow()

    private val _apiConfig = MutableStateFlow(apiBackendManager.getApiConfig())
    val apiConfig: StateFlow<ApiConfig> = _apiConfig.asStateFlow()

    val allCreations: StateFlow<List<CreationItem>> = repository.getAllCreations()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    init {
        viewModelScope.launch {
            repository.initializePreloadedIfEmpty()
        }
    }

    fun selectTab(tab: NavigationTab) {
        _currentTab.value = tab
    }

    fun setPrompt(text: String) {
        _prompt.value = text
    }

    fun useExamplePrompt() {
        _prompt.value = examplePrompt
        _selectedCategory.value = CreationCategory.AI_IMAGE
        _selectedAspectRatio.value = "9:16"
        _selectedStyle.value = "Cinematic 3D"
    }

    fun selectCategory(category: CreationCategory) {
        if (category == CreationCategory.MY_CREATIONS) {
            _currentTab.value = NavigationTab.CREATIONS
        } else {
            _selectedCategory.value = category
            if (_prompt.value.isBlank()) {
                // do not overwrite if user has typed something
            }
        }
    }

    fun selectAspectRatio(ratio: String) {
        _selectedAspectRatio.value = ratio
    }

    fun selectStyle(style: String) {
        _selectedStyle.value = style
    }

    fun selectCreation(item: CreationItem?) {
        _selectedCreation.value = item
    }

    fun setApiConfigDialogVisible(visible: Boolean) {
        _showApiConfigDialog.value = visible
    }

    fun setBackendNoticeDialogVisible(visible: Boolean) {
        _showBackendNoticeDialog.value = visible
    }

    fun setCreditsDialogVisible(visible: Boolean) {
        _showCreditsDialog.value = visible
    }

    fun saveApiConfig(newConfig: ApiConfig) {
        apiBackendManager.saveApiConfig(newConfig)
        _apiConfig.value = newConfig
    }

    fun refillCredits(amount: Int = 50) {
        repository.addCredits(amount)
        _creditsBalance.value = repository.getCreditsBalance()
    }

    fun triggerVibration() {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                vibrator?.vibrate(VibrationEffect.createOneShot(40, VibrationEffect.DEFAULT_AMPLITUDE))
            } else {
                @Suppress("DEPRECATION")
                vibrator?.vibrate(40)
            }
        } catch (_: Exception) {}
    }

    fun onGenerateClicked() {
        val currentPrompt = _prompt.value.trim().ifEmpty { examplePrompt }
        val category = _selectedCategory.value
        val cost = category.defaultCost

        if (_creditsBalance.value < cost) {
            _showCreditsDialog.value = true
            return
        }

        val hasBackend = apiBackendManager.hasValidBackend()
        // If no real backend key is connected, show the transparent backend modal
        // explaining real backend connection requirements and offering live configuration or preview simulation.
        if (!hasBackend) {
            _showBackendNoticeDialog.value = true
            return
        }

        executeGenerationPipeline(currentPrompt, category, cost, useRealApi = true)
    }

    fun executeGenerationPipeline(
        promptText: String,
        category: CreationCategory,
        cost: Int,
        useRealApi: Boolean = false
    ) {
        viewModelScope.launch {
            if (!repository.deductCredits(cost)) {
                _showCreditsDialog.value = true
                return@launch
            }
            _creditsBalance.value = repository.getCreditsBalance()

            _generationState.value = GenerationState(
                isGenerating = true,
                currentStep = "Connecting to ${category.title} inference worker...",
                progress = 0.15f
            )
            triggerVibration()

            delay(700)
            _generationState.value = _generationState.value.copy(
                currentStep = "Conditioning latent space: ${_selectedStyle.value}...",
                progress = 0.40f
            )

            delay(800)
            _generationState.value = _generationState.value.copy(
                currentStep = "Synthesizing multi-modal layers (${_selectedAspectRatio.value})...",
                progress = 0.70f
            )

            var outputContent: String? = null
            var drawableRes: Int? = null

            // If real API is available and category is story or script
            if (useRealApi && (category == CreationCategory.AI_STORY || category == CreationCategory.TEXT_TO_SPEECH)) {
                when (val result = apiBackendManager.generateStoryOrScript(promptText)) {
                    is ApiGenerationResult.Success -> {
                        outputContent = result.content
                    }
                    is ApiGenerationResult.Error -> {
                        outputContent = "Generated via ${category.title} fallback: $promptText"
                    }
                    is ApiGenerationResult.BackendRequired -> {
                        outputContent = "Generated preview for: $promptText"
                    }
                }
            } else {
                when (category) {
                    CreationCategory.AI_IMAGE -> {
                        drawableRes = if (promptText.contains("tomato", ignoreCase = true)) {
                            R.drawable.hero_ai_tomato_1790666843637
                        } else {
                            R.drawable.hero_ai_tomato_1790666843637
                        }
                        outputContent = "High fidelity ${_selectedStyle.value} image synthesized at ${_selectedAspectRatio.value}."
                    }
                    CreationCategory.AI_VIDEO, CreationCategory.IMAGE_TO_VIDEO -> {
                        drawableRes = R.drawable.card_ai_video_1790666856784
                        outputContent = "4K 60fps motion render compiled with dynamic lighting and camera sweep."
                    }
                    CreationCategory.AI_MUSIC -> {
                        drawableRes = R.drawable.card_ai_music_1790666873534
                        outputContent = "Harmonic stereo arrangement rendered at 320kbps MP3 master."
                    }
                    CreationCategory.AI_STORY -> {
                        outputContent = "PROMPT ADAPTATION:\n\"$promptText\"\n\nSYNOPSIS:\nA cinematic narrative exploring destiny, innovation, and uncharted horizons in the vibrant digital frontier."
                    }
                    CreationCategory.AI_VOICE, CreationCategory.TEXT_TO_SPEECH -> {
                        outputContent = "Neural voice synthesized with studio warm acoustic presence."
                    }
                    CreationCategory.SPEECH_TO_TEXT -> {
                        outputContent = "TRANSCRIPTION:\n\"$promptText\" [Confidence: 99.4%]"
                    }
                    CreationCategory.AI_ENHANCE -> {
                        drawableRes = R.drawable.hero_ai_tomato_1790666843637
                        outputContent = "Enhanced with 4x Super Resolution and neural denoise filter."
                    }
                    CreationCategory.MY_CREATIONS -> null
                }
            }

            delay(600)
            _generationState.value = _generationState.value.copy(
                currentStep = "Packaging final output & storing in creations...",
                progress = 0.95f
            )

            val newItem = CreationItem(
                id = System.currentTimeMillis(),
                title = promptText.take(30) + if (promptText.length > 30) "..." else "",
                prompt = promptText,
                category = category,
                aspectRatio = _selectedAspectRatio.value,
                drawableRes = drawableRes,
                modelName = "AJAY Omni v3 (${category.title})",
                creditsCost = cost,
                isFavorite = false,
                outputContent = outputContent,
                audioDuration = if (category == CreationCategory.AI_MUSIC || category == CreationCategory.AI_VOICE) "01:30" else null
            )

            repository.saveCreation(newItem)

            delay(400)
            triggerVibration()
            _generationState.value = GenerationState(
                isGenerating = false,
                currentStep = "Done!",
                progress = 1.0f,
                completedItem = newItem
            )
        }
    }

    fun dismissGenerationDialog() {
        _generationState.value = GenerationState()
    }

    fun toggleFavorite(item: CreationItem) {
        viewModelScope.launch {
            repository.toggleFavorite(item.id, item.isFavorite)
        }
    }

    fun deleteCreation(item: CreationItem) {
        viewModelScope.launch {
            repository.deleteCreation(item.id)
            if (_selectedCreation.value?.id == item.id) {
                _selectedCreation.value = null
            }
        }
    }
}
