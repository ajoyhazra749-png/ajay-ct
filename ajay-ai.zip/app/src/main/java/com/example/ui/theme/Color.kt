package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Obsidian Dark Theme Base
val DarkBackground = Color(0xFF090A10)
val DarkSurface = Color(0xFF12141F)
val DarkSurfaceVariant = Color(0xFF1B1E2E)
val DarkSurfaceSubtle = Color(0xFF23273D)

// Brand Gradients & Accents
val ElectricViolet = Color(0xFF8B5CF6)
val ElectricVioletLight = Color(0xFFA78BFA)
val NeonCyan = Color(0xFF06B6D4)
val NeonCyanLight = Color(0xFF22D3EE)
val HotPink = Color(0xFFEC4899)
val HotPinkLight = Color(0xFFF472B6)
val SunsetAmber = Color(0xFFF59E0B)
val EmeraldGreen = Color(0xFF10B981)

// UI Text & Border
val TextPrimary = Color(0xFFF8FAFC)
val TextSecondary = Color(0xFF94A3B8)
val TextMuted = Color(0xFF64748B)
val BorderSubtle = Color(0x338B5CF6)
val CardBorder = Color(0x24FFFFFF)

// Legacy Theme mapping
val Purple80 = ElectricVioletLight
val PurpleGrey80 = Color(0xFFCCC2DC)
val Pink80 = HotPinkLight

val Purple40 = ElectricViolet
val PurpleGrey40 = Color(0xFF625b71)
val Pink40 = HotPink
