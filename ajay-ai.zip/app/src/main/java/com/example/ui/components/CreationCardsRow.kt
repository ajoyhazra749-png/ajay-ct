package com.example.ui.components

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowForward
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.data.model.CreationCategory
import com.example.ui.theme.DarkSurface
import com.example.ui.theme.DarkSurfaceVariant
import com.example.ui.theme.ElectricViolet
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

data class CreationCardSpec(
    val category: CreationCategory,
    val previewDrawableRes: Int?,
    val badgeText: String,
    val description: String
)

@Composable
fun CreationCardsRow(
    selectedCategory: CreationCategory,
    onCategorySelect: (CreationCategory) -> Unit,
    modifier: Modifier = Modifier
) {
    val cards = listOf(
        CreationCardSpec(
            category = CreationCategory.AI_IMAGE,
            previewDrawableRes = R.drawable.hero_ai_tomato_1790666843637,
            badgeText = "8K ULTRA",
            description = "Photorealism, 3D cartoons & digital concept art"
        ),
        CreationCardSpec(
            category = CreationCategory.AI_VIDEO,
            previewDrawableRes = R.drawable.card_ai_video_1790666856784,
            badgeText = "60 FPS 4K",
            description = "Cinematic camera motions, loops & scene sweeps"
        ),
        CreationCardSpec(
            category = CreationCategory.AI_VOICE,
            previewDrawableRes = null,
            badgeText = "STUDIO HD",
            description = "Hyperrealistic voice clones & emotion tuning"
        ),
        CreationCardSpec(
            category = CreationCategory.AI_STORY,
            previewDrawableRes = null,
            badgeText = "GEMINI 2.5",
            description = "Novels, screenplays, character dialogues & plots"
        ),
        CreationCardSpec(
            category = CreationCategory.AI_MUSIC,
            previewDrawableRes = R.drawable.card_ai_music_1790666873534,
            badgeText = "HI-FI STEMS",
            description = "Full tracks, synthwave beats & custom stems"
        )
    )

    Column(modifier = modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 6.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "Creation Studios",
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold,
                color = TextPrimary
            )
            Text(
                text = "5 Core Engines",
                fontSize = 12.sp,
                fontWeight = FontWeight.Medium,
                color = NeonCyan
            )
        }

        Spacer(modifier = Modifier.height(6.dp))

        LazyRow(
            contentPadding = PaddingValues(horizontal = 16.dp),
            horizontalArrangement = Arrangement.spacedBy(14.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            items(cards) { spec ->
                CreationCardItem(
                    spec = spec,
                    isSelected = selectedCategory == spec.category,
                    onClick = { onCategorySelect(spec.category) }
                )
            }
        }
    }
}

@Composable
fun CreationCardItem(
    spec: CreationCardSpec,
    isSelected: Boolean,
    onClick: () -> Unit
) {
    val borderBrush = if (isSelected) {
        Brush.horizontalGradient(listOf(ElectricViolet, NeonCyan))
    } else {
        Brush.horizontalGradient(listOf(Color(0x338B5CF6), Color(0x15FFFFFF)))
    }

    Box(
        modifier = Modifier
            .width(220.dp)
            .height(170.dp)
            .clip(RoundedCornerShape(22.dp))
            .background(DarkSurface)
            .border(if (isSelected) 2.dp else 1.dp, borderBrush, RoundedCornerShape(22.dp))
            .clickable { onClick() }
            .testTag("creation_card_${spec.category.id}")
    ) {
        // Background art if available
        if (spec.previewDrawableRes != null) {
            Image(
                painter = painterResource(id = spec.previewDrawableRes),
                contentDescription = spec.category.title,
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize()
            )
            // Dark gradient overlay for readability
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(
                        Brush.verticalGradient(
                            listOf(
                                Color(0x40000000),
                                Color(0x990A0B12),
                                Color(0xF20A0B12)
                            )
                        )
                    )
            )
        } else {
            // Subtle graphic backdrop with category gradient
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(
                        Brush.radialGradient(
                            colors = listOf(
                                spec.category.gradientColors.first().copy(alpha = 0.35f),
                                DarkSurface
                            ),
                            radius = 400f
                        )
                    )
            )
        }

        // Content layout
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(14.dp),
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            // Top row: Icon + Badge
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .size(36.dp)
                        .clip(RoundedCornerShape(10.dp))
                        .background(spec.category.brush),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = spec.category.icon,
                        contentDescription = spec.category.title,
                        tint = Color.White,
                        modifier = Modifier.size(20.dp)
                    )
                }

                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .background(Color(0x80000000))
                        .border(1.dp, Color(0x33FFFFFF), RoundedCornerShape(8.dp))
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                ) {
                    Text(
                        text = spec.badgeText,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.ExtraBold,
                        letterSpacing = 0.5.sp,
                        color = Color.White
                    )
                }
            }

            // Bottom section: Title, description, cost
            Column {
                Text(
                    text = spec.category.title,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold,
                    color = TextPrimary
                )
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = spec.description,
                    fontSize = 11.sp,
                    color = TextSecondary,
                    lineHeight = 15.sp,
                    maxLines = 2
                )
                Spacer(modifier = Modifier.height(6.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "${spec.category.defaultCost} Credits / run",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = NeonCyan
                    )
                    Icon(
                        imageVector = Icons.Default.ArrowForward,
                        contentDescription = "Select",
                        tint = if (isSelected) NeonCyan else TextMuted,
                        modifier = Modifier.size(14.dp)
                    )
                }
            }
        }
    }
}
