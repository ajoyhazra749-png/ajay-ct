package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ui.components.AjayTopBar
import com.example.ui.components.ApiConfigDialog
import com.example.ui.components.BackendNoticeDialog
import com.example.ui.components.BottomNavBar
import com.example.ui.components.CreationDetailSheet
import com.example.ui.components.CreditsDialog
import com.example.ui.components.GenerationProgressDialog
import com.example.ui.screens.CreateScreen
import com.example.ui.screens.CreationsScreen
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.ProfileScreen
import com.example.ui.theme.DarkBackground
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.viewmodel.AjayAiViewModel
import com.example.ui.viewmodel.NavigationTab

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                AjayAiApp()
            }
        }
    }
}

@Composable
fun AjayAiApp(
    viewModel: AjayAiViewModel = viewModel()
) {
    val currentTab by viewModel.currentTab.collectAsStateWithLifecycle()
    val prompt by viewModel.prompt.collectAsStateWithLifecycle()
    val selectedCategory by viewModel.selectedCategory.collectAsStateWithLifecycle()
    val selectedAspectRatio by viewModel.selectedAspectRatio.collectAsStateWithLifecycle()
    val selectedStyle by viewModel.selectedStyle.collectAsStateWithLifecycle()
    val creditsBalance by viewModel.creditsBalance.collectAsStateWithLifecycle()
    val generationState by viewModel.generationState.collectAsStateWithLifecycle()
    val selectedCreation by viewModel.selectedCreation.collectAsStateWithLifecycle()
    val allCreations by viewModel.allCreations.collectAsStateWithLifecycle()
    val apiConfig by viewModel.apiConfig.collectAsStateWithLifecycle()

    val showApiConfigDialog by viewModel.showApiConfigDialog.collectAsStateWithLifecycle()
    val showBackendNoticeDialog by viewModel.showBackendNoticeDialog.collectAsStateWithLifecycle()
    val showCreditsDialog by viewModel.showCreditsDialog.collectAsStateWithLifecycle()

    // Handle back button on sub-tabs
    BackHandler(enabled = currentTab != NavigationTab.HOME) {
        viewModel.selectTab(NavigationTab.HOME)
    }

    val hasBackendConfigured = apiConfig.geminiApiKey.isNotBlank() || apiConfig.customApiEndpoint.isNotBlank()

    Scaffold(
        modifier = Modifier
            .fillMaxSize()
            .background(DarkBackground)
            .windowInsetsPadding(WindowInsets.statusBars),
        containerColor = DarkBackground,
        topBar = {
            AjayTopBar(
                credits = creditsBalance,
                hasBackendConfigured = hasBackendConfigured,
                onCreditsClick = { viewModel.setCreditsDialogVisible(true) },
                onApiConfigClick = { viewModel.setApiConfigDialogVisible(true) }
            )
        },
        bottomBar = {
            BottomNavBar(
                currentTab = currentTab,
                onTabSelected = { viewModel.selectTab(it) }
            )
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            AnimatedContent(
                targetState = currentTab,
                transitionSpec = { fadeIn() togetherWith fadeOut() },
                label = "ScreenTransition"
            ) { targetTab ->
                when (targetTab) {
                    NavigationTab.HOME -> HomeScreen(
                        prompt = prompt,
                        examplePrompt = viewModel.examplePrompt,
                        selectedCategory = selectedCategory,
                        creditsCost = selectedCategory.defaultCost,
                        onPromptChange = { viewModel.setPrompt(it) },
                        onUseExamplePrompt = { viewModel.useExamplePrompt() },
                        onCategorySelect = { viewModel.selectCategory(it) },
                        onGenerateClick = { viewModel.onGenerateClicked() }
                    )

                    NavigationTab.CREATE -> CreateScreen(
                        prompt = prompt,
                        selectedCategory = selectedCategory,
                        selectedAspectRatio = selectedAspectRatio,
                        selectedStyle = selectedStyle,
                        creditsCost = selectedCategory.defaultCost,
                        onPromptChange = { viewModel.setPrompt(it) },
                        onCategorySelect = { viewModel.selectCategory(it) },
                        onAspectRatioSelect = { viewModel.selectAspectRatio(it) },
                        onStyleSelect = { viewModel.selectStyle(it) },
                        onGenerateClick = { viewModel.onGenerateClicked() }
                    )

                    NavigationTab.CREATIONS -> CreationsScreen(
                        creations = allCreations,
                        onSelectCreation = { viewModel.selectCreation(it) },
                        onToggleFavorite = { viewModel.toggleFavorite(it) },
                        onStartCreateClick = { viewModel.selectTab(NavigationTab.CREATE) }
                    )

                    NavigationTab.PROFILE -> ProfileScreen(
                        credits = creditsBalance,
                        apiConfig = apiConfig,
                        totalCreationsCount = allCreations.size,
                        onRefillCredits = { viewModel.refillCredits(it) },
                        onOpenApiConfig = { viewModel.setApiConfigDialogVisible(true) }
                    )
                }
            }
        }
    }

    // Backend Requirement / Info Dialog
    if (showBackendNoticeDialog) {
        BackendNoticeDialog(
            onDismiss = { viewModel.setBackendNoticeDialogVisible(false) },
            onConfigureApiKey = {
                viewModel.setBackendNoticeDialogVisible(false)
                viewModel.setApiConfigDialogVisible(true)
            },
            onRunLocalPreview = {
                viewModel.setBackendNoticeDialogVisible(false)
                val currentPrompt = prompt.trim().ifEmpty { viewModel.examplePrompt }
                viewModel.executeGenerationPipeline(
                    promptText = currentPrompt,
                    category = selectedCategory,
                    cost = selectedCategory.defaultCost,
                    useRealApi = false
                )
            }
        )
    }

    // API & Keys Configuration Dialog
    if (showApiConfigDialog) {
        ApiConfigDialog(
            initialConfig = apiConfig,
            onSave = {
                viewModel.saveApiConfig(it)
                viewModel.setApiConfigDialogVisible(false)
            },
            onDismiss = { viewModel.setApiConfigDialogVisible(false) }
        )
    }

    // Credits Balance Dialog
    if (showCreditsDialog) {
        CreditsDialog(
            credits = creditsBalance,
            onRefillCredits = { viewModel.refillCredits(it) },
            onDismiss = { viewModel.setCreditsDialogVisible(false) }
        )
    }

    // Generation Progress Modal
    if (generationState.isGenerating || generationState.completedItem != null) {
        GenerationProgressDialog(
            state = generationState,
            onViewResult = {
                val item = generationState.completedItem
                viewModel.dismissGenerationDialog()
                viewModel.selectTab(NavigationTab.CREATIONS)
                if (item != null) {
                    viewModel.selectCreation(item)
                }
            },
            onDismiss = { viewModel.dismissGenerationDialog() }
        )
    }

    // Creation Detail Bottom Sheet
    selectedCreation?.let { item ->
        CreationDetailSheet(
            item = item,
            onDismiss = { viewModel.selectCreation(null) },
            onToggleFavorite = { viewModel.toggleFavorite(it) },
            onDelete = { viewModel.deleteCreation(it) }
        )
    }
}
